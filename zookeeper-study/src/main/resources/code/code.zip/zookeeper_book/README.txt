1. The project is encoded by UTF-8
2. 有任何问题请联系nileader@gmail.com。